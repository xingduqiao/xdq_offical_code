<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewspublicadd`;");
E_C("CREATE TABLE `phome_enewspublicadd` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `ctimeopen` tinyint(1) NOT NULL default '0',
  `ctimelast` int(10) unsigned NOT NULL default '0',
  `ctimeindex` int(11) NOT NULL default '0',
  `ctimeclass` int(11) NOT NULL default '0',
  `ctimelist` int(11) NOT NULL default '0',
  `ctimetext` int(11) NOT NULL default '0',
  `ctimett` int(11) NOT NULL default '0',
  `ctimetags` int(11) NOT NULL default '0',
  `ctimegids` varchar(255) NOT NULL default '',
  `ctimecids` varchar(255) NOT NULL default '',
  `ctimernd` varchar(60) NOT NULL default '',
  `ctimeaddre` tinyint(4) NOT NULL default '0',
  `ctimeqaddre` tinyint(4) NOT NULL default '0',
  `autodoopen` tinyint(1) NOT NULL default '0',
  `autodouser` varchar(30) NOT NULL default '',
  `autodopass` varchar(32) NOT NULL default '',
  `autodosalt` varchar(20) NOT NULL default '',
  `autodoshowkey` tinyint(1) NOT NULL default '0',
  `autodotime` int(11) NOT NULL default '0',
  `autodoline` int(11) NOT NULL default '0',
  `autodovar` varchar(20) NOT NULL default '',
  `autodoval` varchar(60) NOT NULL default '',
  `autodoshow` tinyint(1) NOT NULL default '0',
  `autodofile` tinyint(1) NOT NULL default '0',
  `autodopostpass` varchar(120) NOT NULL default '',
  `autodoss` tinyint(1) NOT NULL default '0',
  `autodoaction` varchar(200) NOT NULL default '',
  `autodock` tinyint(1) NOT NULL default '0',
  `digglevel` int(11) NOT NULL default '0',
  `diggcmids` varchar(255) NOT NULL default '',
  `toqjf` text NOT NULL,
  `qtoqjf` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewspublicadd` values('1','0','0','0','0','0','0','0','0','','',0x746d4a696d436b7a5151583472706759716e6162714b79544a4977427057336c6a386c6d6f7754546643,'0','0','0','','','','0','100','12','','','1','0',0x4f6e5079644e4478574a78455a374133667333775649776254355555683570363958695071486d397a423278365644374d5a68644d71767556754854,'0',0x2c656d702c,'0','0','','','');");

@include("../../inc/footer.php");
?>