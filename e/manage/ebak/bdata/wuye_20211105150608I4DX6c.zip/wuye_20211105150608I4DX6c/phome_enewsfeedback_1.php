<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsfeedback`;");
E_C("CREATE TABLE `phome_enewsfeedback` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `bid` smallint(5) unsigned NOT NULL default '0',
  `title` varchar(120) NOT NULL default '',
  `saytext` text NOT NULL,
  `name` varchar(30) NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `mycall` varchar(30) NOT NULL default '',
  `homepage` varchar(160) NOT NULL default '',
  `company` varchar(80) NOT NULL default '',
  `address` varchar(255) NOT NULL default '',
  `saytime` datetime NOT NULL default '0000-00-00 00:00:00',
  `job` varchar(36) NOT NULL default '',
  `ip` varchar(20) NOT NULL default '',
  `filepath` varchar(20) NOT NULL default '',
  `filename` text NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL default '0',
  `username` varchar(20) NOT NULL default '',
  `haveread` tinyint(1) NOT NULL default '0',
  `eipport` varchar(6) NOT NULL default '',
  `cpxz` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `bid` (`bid`),
  KEY `haveread` (`haveread`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewsfeedback` values('1','2',0xe8a5bfe9878ee4b883e6bf91efbc9ae6b885e6b581e4b880e888ace79a84e7ac91e5aeb9e6b281e4babae5bf83e884be,0xe69e97e58e85,0xe78e8be4ba94,'',0x32313433343133,'','','','2021-11-05 11:17:43','',0x3132372e302e302e31,'','','0','','1',0x3631383537,'');");
E_D("replace into `phome_enewsfeedback` values('2','2','','',0xe5bca0e5bcba,'',0x32313433343133,'','','','2021-11-05 11:27:57','',0x3132372e302e302e31,'','','0','','1',0x3632353133,0x7ce4baa7e59381312ee7adb9e5a487e68890e7ab8be9a696e6aca1e4b89ae4b8bbe5a4a7e4bc9a7ce4baa7e59381362ee5b08fe58cbae7a798e4b9a6e69c8de58aa17c);");
E_D("replace into `phome_enewsfeedback` values('3','2','','',0xe5b08fe4ba91,'',0x313338343635343635343435,'','','','2021-11-05 11:59:36','',0x3132372e302e302e31,'','','0','','1',0x3634373730,0x7ce4baa7e59381332ee7adb9e58892e7bb84e7bb87e4b89ae4b8bbe5a794e59198e4bc9ae68da2e5b18ae4b88ee5a794e59198e8a1a5e98089e5b7a5e4bd9c7ce4baa7e59381382ee689bfe68ea5e69fa5e9aa8c7ce4baa7e59381392ee5b08fe58cbae68b9be6a087e4bba3e79086e69c8de58aa17c);");

@include("../../inc/footer.php");
?>