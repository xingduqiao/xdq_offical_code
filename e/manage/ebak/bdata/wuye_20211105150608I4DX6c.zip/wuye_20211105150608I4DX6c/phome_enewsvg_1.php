<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsvg`;");
E_C("CREATE TABLE `phome_enewsvg` (
  `vgid` smallint(5) unsigned NOT NULL auto_increment,
  `gname` char(60) NOT NULL default '',
  `gids` char(255) NOT NULL default '',
  `ingids` char(255) NOT NULL default '',
  `agids` char(255) NOT NULL default '',
  `mlist` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`vgid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

@include("../../inc/footer.php");
?>