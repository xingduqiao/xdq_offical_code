<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsingroup`;");
E_C("CREATE TABLE `phome_enewsingroup` (
  `gid` smallint(5) unsigned NOT NULL auto_increment,
  `gname` char(60) NOT NULL default '',
  `myorder` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`gid`),
  KEY `myorder` (`myorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

@include("../../inc/footer.php");
?>