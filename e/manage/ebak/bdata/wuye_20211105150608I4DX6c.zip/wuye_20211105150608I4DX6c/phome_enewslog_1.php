<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewslog`;");
E_C("CREATE TABLE `phome_enewslog` (
  `loginid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(30) NOT NULL default '',
  `logintime` datetime NOT NULL default '0000-00-00 00:00:00',
  `loginip` varchar(20) NOT NULL default '',
  `status` tinyint(1) NOT NULL default '0',
  `password` varchar(30) NOT NULL default '',
  `loginauth` tinyint(1) NOT NULL default '0',
  `ipport` varchar(6) NOT NULL default '',
  PRIMARY KEY  (`loginid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewslog` values('1',0x61646d696e,'2021-10-14 08:56:39',0x3132372e302e302e31,'1','','0',0x3530363639);");
E_D("replace into `phome_enewslog` values('2',0x61646d696e,'2021-10-14 10:43:36',0x3132372e302e302e31,'1','','0',0x3535313534);");
E_D("replace into `phome_enewslog` values('3',0x61646d696e,'2021-10-14 10:59:52',0x3132372e302e302e31,'1','','0',0x3539383139);");
E_D("replace into `phome_enewslog` values('4',0x61646d696e,'2021-10-14 13:29:38',0x3132372e302e302e31,'1','','0',0x3530333934);");
E_D("replace into `phome_enewslog` values('5',0x61646d696e,'2021-10-14 13:54:32',0x3132372e302e302e31,'1','','0',0x3530393530);");
E_D("replace into `phome_enewslog` values('6',0x61646d696e,'2021-10-14 14:01:12',0x3132372e302e302e31,'1','','0',0x3531393336);");
E_D("replace into `phome_enewslog` values('7',0x61646d696e,'2021-10-15 14:49:40',0x3132372e302e302e31,'1','','0',0x3634353538);");
E_D("replace into `phome_enewslog` values('8',0x61646d696e,'2021-10-15 16:46:29',0x3132372e302e302e31,'1','','0',0x3439383132);");
E_D("replace into `phome_enewslog` values('9',0x61646d696e,'2021-10-15 18:45:26',0x3132372e302e302e31,'1','','0',0x3634313039);");
E_D("replace into `phome_enewslog` values('10',0x61646d696e,'2021-10-18 07:30:35',0x3132372e302e302e31,'1','','0',0x3633393530);");
E_D("replace into `phome_enewslog` values('11',0x61646d696e,'2021-10-26 16:44:39',0x3132372e302e302e31,'1','','0',0x3634393030);");
E_D("replace into `phome_enewslog` values('12',0x61646d696e,'2021-10-26 19:18:57',0x3132372e302e302e31,'1','','0',0x3630313532);");
E_D("replace into `phome_enewslog` values('13',0x61646d696e,'2021-10-26 20:07:59',0x3232332e3130342e31342e3838,'1','','0',0x3432353232);");
E_D("replace into `phome_enewslog` values('14',0x61646d696e,'2021-11-01 10:20:49',0x3231382e32362e3135392e3335,'1','','0',0x3131333838);");
E_D("replace into `phome_enewslog` values('15',0x61646d696e,'2021-11-04 14:31:18',0x3231382e32362e3135392e313339,'1','','0',0x3134363937);");
E_D("replace into `phome_enewslog` values('16',0x61646d696e,'2021-11-04 14:48:36',0x3132372e302e302e31,'1','','0',0x3630353339);");
E_D("replace into `phome_enewslog` values('17',0x61646d696e,'2021-11-04 20:48:48',0x3132372e302e302e31,'1','','0',0x3534313239);");
E_D("replace into `phome_enewslog` values('18',0x61646d696e,'2021-11-05 08:11:53',0x3132372e302e302e31,'1','','0',0x3539333731);");
E_D("replace into `phome_enewslog` values('19',0x61646d696e,'2021-11-05 11:01:27',0x3132372e302e302e31,'1','','0',0x3630373532);");
E_D("replace into `phome_enewslog` values('20',0x61646d696e,'2021-11-05 13:22:28',0x3132372e302e302e31,'1','','0',0x3439333739);");
E_D("replace into `phome_enewslog` values('21',0x61646d696e,'2021-11-05 14:51:09',0x3132372e302e302e31,'1','','0',0x3535323439);");

@include("../../inc/footer.php");
?>