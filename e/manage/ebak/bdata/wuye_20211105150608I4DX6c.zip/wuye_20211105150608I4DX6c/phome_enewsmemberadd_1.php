<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `phome_enewsmemberadd`;");
E_C("CREATE TABLE `phome_enewsmemberadd` (
  `userid` int(10) unsigned NOT NULL default '0',
  `truename` varchar(20) NOT NULL default '',
  `jbname` varchar(25) NOT NULL default '',
  `jbrsfz` varchar(120) NOT NULL default '',
  `mycall` varchar(30) NOT NULL default '',
  `comemail` varchar(30) NOT NULL default '',
  `address` varchar(255) NOT NULL default '',
  `qysh` varchar(100) NOT NULL default '',
  `spacestyleid` smallint(6) NOT NULL default '0',
  `jbrtel` varchar(200) NOT NULL default '',
  `khhmc` varchar(100) NOT NULL default '',
  `company` varchar(255) NOT NULL default '',
  `frsfz` varchar(255) NOT NULL default '',
  `userpic` varchar(200) NOT NULL default '',
  `spacename` varchar(255) NOT NULL default '',
  `spacegg` text NOT NULL,
  `viewstats` int(11) NOT NULL default '0',
  `regip` varchar(20) NOT NULL default '',
  `lasttime` int(10) unsigned NOT NULL default '0',
  `lastip` varchar(20) NOT NULL default '',
  `loginnum` int(10) unsigned NOT NULL default '0',
  `regipport` varchar(6) NOT NULL default '',
  `lastipport` varchar(6) NOT NULL default '',
  `comzh` varchar(100) NOT NULL default '',
  `yyzz` varchar(100) NOT NULL default '',
  `qyzzzs` varchar(100) NOT NULL default '',
  `sqwts` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `phome_enewsmemberadd` values('1','','','','','','','','1','','','','','','','','0',0x3132372e302e302e31,'1636039561',0x3132372e302e302e31,'4',0x3539373234,0x3535343937,'','','','');");

@include("../../inc/footer.php");
?>